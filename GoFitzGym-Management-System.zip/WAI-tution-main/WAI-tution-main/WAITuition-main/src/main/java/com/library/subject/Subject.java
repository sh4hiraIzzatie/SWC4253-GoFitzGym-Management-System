/**
 * Entity 'Book' class.
 * Columns - Id, title, isbn, genre
 */
package com.library.subject;

import javax.persistence.*;

@Entity()
// Specify primary table for entity
@Table(name = "subject")

public class Subject {
    // Specify id as primary key
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false, unique = true, length = 20)
    private String subject_name;
    @Column(length = 100, nullable = false)
    private String date;
    @Column(length = 40, nullable = false)
    private String status;
    @Column(length = 40, nullable = false)
    private int total_stud;

    public Integer getId() {
        return id;
    }
    // Setter for id
    public void setId(Integer id) {
        this.id = id;
    }
    public String getSubject_name() {
        return subject_name;
    }
    // Setter for subject_name
    public void setSubject_name(String subject_name) {
        this.subject_name = subject_name;
    }
    public String getDate() {
        return date;
    }
    // Setter for date
    public void setDate(String date) {
        this.date = date;
    }
    public String getStatus() {
        return status;
    }
    // Setter for time
    public void setStatus(String status) {
        this.status = status;
    }
    public Integer getTotal_stud() {
        return total_stud;
    }
    // Setter for total_stud
    public void setTotal_stud(Integer total_stud) {
        this.total_stud = total_stud;
    }
}
